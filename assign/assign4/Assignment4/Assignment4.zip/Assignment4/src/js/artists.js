/**
 * artists.js
 *
 * The app's list of Artists
 */

window.artists = [
  
{ id: "artist1", name: "BTS", links:[{url: "https://en.wikipedia.org/wiki/BTS", add:"wikipedia"}, {url:"https://ibighit.com/bts/eng/",add:"official"}]},
{ id: "artist2", name: "BLACKPINK", links:[{url:"https://en.wikipedia.org/wiki/Blackpink", add:"wikipedia"}, {url:"https://www.ygfamily.com/artist/main.asp?LANGDIV=K&ATYPE=2&ARTIDX=70",add:"official"}]}, 

{ id: "artist3", name: "PSY", links:[{url:"https://en.wikipedia.org/wiki/Psy", add:"wikipedia"}, {url:"https://twitter.com/psy_oppa",add:"twitter"}]}

];
