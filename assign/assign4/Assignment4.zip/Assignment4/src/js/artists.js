/**
 * artists.js
 *
 * The app's list of Artists
 */

window.artists = [
  /* TODO */
];
