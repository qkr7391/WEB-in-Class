/**
 * songs.js
 *
 * The app's songs
 */

window.songs = [
  /* TODO */
];
